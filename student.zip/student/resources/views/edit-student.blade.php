<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="_token" content="{{ csrf_token() }}" />
	<title>Document</title>
	<!-- Latest compiled and minified CSS & JS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
	<script src="//code.jquery.com/jquery.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Add Student</h3>
					</div>
					<div class="panel-body">
						<form action="{{URL('/update-student')}}" method="POST" role="form" enctype="multipart/form-data">
							{{csrf_field()}}
							<input type="hidden" name ="id" id="id" value= "{{$student->id}}" >
							<div class="form-group">
								<label for="name">Name</label>
								<input type="text" class="form-control" value ="{{$student->name}}" name="name" id="name" placeholder="student name">
							</div>


							<div class="form-group">
								<label for="roll_no">Roll_No.</label>
								<input type="text" class="form-control" name="roll_no" value ="{{$student->roll_no}}" id="roll_no" placeholder="student Roll_No">
							</div>

							<div class="form-group">
								<label for="class">Class</label>
								<input type="text" class="form-control" value ="{{$student->class}}" name="class" id="class" placeholder="student Class">
							</div>
							<div class="form-group">
								<label for="image">Image</label>
								<input type="file" class="form-control" name="image" id="image" placeholder="student Image">
								<img src="{{$student->image}}" alt="" height = "50" width= "50">
							</div>


							<button type="button" id="submit" class="btn btn-primary">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

<script>
	$(document).ready(function(){

		$("#submit").click(function(){
			var fd = new FormData();    
			fd.append( 'image', $('#image')[0].files[0] );
			fd.append( 'name', $('#name').val());
			fd.append( 'class', $('#class').val());
			fd.append( 'roll_no', $('#roll_no').val());
			$.ajaxSetup({ headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')} });

			var url = "{{Url('/add-student')}}";
			$.ajax({
				url: url,
				data: fd,
				processData: false,
				contentType: false,
				cache: false,
				type: 'POST',
				success: function(data){
					if(data.flag){
						alert(data.message);
						window.location.href = "{{Url('/')}}";
					}
				}
			});
		});
	});
</script>

</html>