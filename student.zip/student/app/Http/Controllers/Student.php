<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Student extends Controller
{

//list all student  
	public function index()
	{
		$students = \App\Student::all();
		$data['students'] = $students;
		return view('students',$data);
	}

	public function getAddStudent()
	{
		return view('add-student');
	}

//add-student in db
	
	public function postAddStudent(Request $request)
	{
		$response 			= 	array();
		$student 			= 	new \App\Student();
		$student->name 		= 	$request->name;
		$student->class 	= 	$request->class;
		$student->roll_no 	= 	$request->roll_no;

		$file 		= 	$request->file('image');
		$filename 	= 	$file->getClientOriginalName();
		$file->move('uploads',$filename);

		$student->image 	= 	url('/').'/uploads/'.$filename;
		
		if($student->save()){
			$response['flag'] = true;
			$response['message'] = 'created successfully';
		}else{

			$response['flag'] = false;
			$response['message'] = 'fail to create';
		}

		return response()->json($response);
	}





	public function getEditStudent($id)
	{
		$response = array();
		$student = \App\Student::find($id);
		
		if(is_null($student)){
			$response['flag'] = false;
			$response['message'] = 'no user found';
		}else{
			$data['student'] = $student;
			return view('edit-student',$data);
		}
		return response()->json($response);
	}

	public function postEditStudent(Request $request)
	{
		$response = array();
		$student = \App\Student::find($request->id);
		if(is_null($student)){
			$response['flag'] = false;
			$response['message'] = 'no user found';
		}else{
			$student->name = $request->name;
			$student->class = $request->class;
			$student->roll_no = $request->roll_no;
			$file = $request->file('image');
			$filename = $file->getClientOriginalName();
			$file->move('uploads',$filename);
			$student->image = url('/').'/uploads/'.$filename;
			if($student->save()){
				$response['flag'] = true;
				$response['message'] = 'updated successfully';
			}else{

				$response['flag'] = false;
				$response['message'] = 'fail to update';
			}
		}
		return response()->json($response);
	}

	public function deleteStudent($id)
	{
		$response = array();
		$student = \App\Student::find($id);
		if(is_null($student)){
			$response['flag'] = false;
			$response['message'] = 'no user found';
		}else{
			if($student->delete()){
				$response['flag'] = true;
				$response['message'] = 'deleted successfully';
			}else{

				$response['flag'] = false;
				$response['message'] = 'fail to delete';
			}
		}
		return response()->json($response);
	}

}
