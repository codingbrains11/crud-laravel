<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/','Student@index');

Route::get('/add-student','Student@getAddStudent');
Route::post('/add-student','Student@postAddStudent');

Route::get('/edit/{id}','Student@getEditStudent');
Route::post('/update-student','Student@postEditStudent');

Route::get('/delete/{id}','Student@deleteStudent');
